package jaima.agent;

/**
 * Write a description of class Actuator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Actuator
{
}
