package jaima.logic.firstorder;

/**
 * @author Ravi Mohan
 * 
 */

public class Connectors {
	public static String AND = "AND";

	public static String OR = "OR";

	public static String NOT = "NOT";

	public static String IMPLIES = "=>";

	public static String BICOND = "<=>";

}