/*
 * Created on Sep 14, 2003 
 *
 */
package jaima.logic.firstorder.parsing.ast;

/**
 * @author Ravi Mohan
 * 
 */

public interface Sentence extends FOLNode {

}
