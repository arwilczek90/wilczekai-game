package jaima.agent;

/**
 * Write a description of class Sensor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Sensor
{

}
